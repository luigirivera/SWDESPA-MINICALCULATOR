/*
    LOPEZ, LUIS ENRICO D.
    RIVERA, LOUIE IV Y.
    SWDESPA S17
*/

import java.util.Scanner;

interface Computor{
	public String compute(float val1, float val2);
}

class Invalid implements Computor{
    public String compute(float val1, float val2)
    {
        return "ERROR: Invalid operation";
    }
}

class Add implements Computor{
	public String compute(float val1, float val2)
	{
		return String.valueOf((int)(val1 + val2));
	}
}

class Subtract implements Computor{
	public String compute(float val1, float val2)
	{
		return String.valueOf((int)(val1 - val2));
	}
}

class Multiply implements Computor{
	public String compute(float val1, float val2)
	{
		float finalans=0;
		for(int i=0; i<val2; i++)
			finalans += val1;
		
		return String.valueOf((int)finalans);
	}
}

class Divide implements Computor{
	public String compute(float val1, float val2)
	{
        if (val2==0)
            return "ERROR: Can't divide by 0";
        else
		{
			int finalans=0;
			do
			{
				
				if(val1-val2>=0)
				{
					val1 -= val2;
					finalans++;
				}
					
			}while(val1>0);
			
			return String.valueOf((int)finalans);
		}
            
	}
}

class ExpressionParser{
    public String[] parse(String raw)
    {
        //placing space between every character
        raw = raw.replace("", " ");
        //removing extra space between numbers joined by decimal point
        raw = raw.replaceAll("[\\.][\\s]", ".");
        raw = raw.replaceAll("[\\s][\\.]", ".");
        //removing extra space between digits of a number
        raw = raw.replaceAll("([0-9])([\\s])([0-9])", "$1$3");
        //removing extra space on the sides
        raw = raw.trim();
        //split expression into 3 strings using whitespace as splitter
        return raw.split("\\s+", 3);
    }
}

class Calculator{
	public void calculatorStart()
	{
        String expression;
        String[] parsedExpression;
        Scanner input = new Scanner(System.in);
        ExpressionParser parser = new ExpressionParser();
		do
		{
			expression = input.nextLine();
			expression = expression.trim();
			if(!expression.equals(Symbols.EXIT.toString()))
			{
                parsedExpression = parser.parse(expression);
                try {
                    printResult(Float.parseFloat(parsedExpression[0]), Float.parseFloat(parsedExpression[2]), findComputor(parsedExpression[1]));
                } catch (Exception e) {
                    System.out.println("ERROR: Invalid Expression");
                }
			}
				
		}while(!expression.equals(Symbols.EXIT.toString()));
			
		input.close();
	}
	
	private Computor findComputor(String symbol) {
        /* Why not switch statement?
            Switch cases would have needed "constant string expression" */
        if (symbol.equals(Symbols.ADD.toString()))
            return new Add();
        else if (symbol.equals(Symbols.SUB.toString()))
            return new Subtract();
        else if (symbol.equals(Symbols.MULT.toString()))
            return new Multiply();
        else if (symbol.equals(Symbols.DIV.toString()))
            return new Divide();
        else
            return new Invalid();
	}
	
	private void printResult(float val1, float val2, Computor computor)
	{
		System.out.println(computor.compute(val1, val2));
	}
	
}

public class MiniCalculator{
	public static void main(String[] args)
	{
		Calculator mc = new Calculator();
		mc.calculatorStart();
	}
}
